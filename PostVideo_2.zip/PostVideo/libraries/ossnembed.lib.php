<?php

require_once(__OSSN_POST__VIDEO . 'plugins/default/wall/templates/wall/user/item.php');

function ossn_embed_create_embed_object3($url, $guid, $videowidth=0) {
	if (!isset($url)) {
		return false;	}{
		return ossn_embed_vimeo_handler3($url, $guid, $videowidth);}  {
		return false;}}
function ossn_embed_add_css3($guid, $width, $height) {
	$videocss = "";
	$vars = array(
		'guid' => $guid,
		'width' => $width,
		'height' => $height);
	return ossn_call_hook('embed', 'video:css', $vars, $videocss);}
print_r($url);
function ossn_embed_add_object3($type, $url, $guid, $width, $height) {
	$videodiv = "<span id=\"ossnembed{$guid}\" class=\"ossn_embed_video ratio ratio-16x9\">";
	switch ($type) {
	   case '192.168.1.38':
                $videodiv .= "<iframe src=\"{$url}\" width=\"$width\" height=\"$height\" allowfullscreen sandbox></iframe>";
                break;	}

	$videodiv .= "</span>";
	return $videodiv;}
function ossn_embed_calc_size3(&$width, &$height, $aspect_ratio, $toolbar_heigh) {
	if (!isset($width) || !is_numeric($width) || $width < 0) {
		$width = 500;}
	$height = round($width / $aspect_ratio) + $toolbar_height;}
function ossn_embed_vimeo_handler3($url, $guid, $videowidth) {
	// this extracts the core part of the url needed for embeding
	$videourl = ossn_embed_vimeo_parse_url3($url);
	if (!isset($videourl)) {
		return false;	}
	ossn_embed_calc_size3($videowidth, $videoheight, 400/300, 0);
	$embed_object = ossn_embed_add_css3($guid, $videowidth, $videoheight);
	$embed_object .= ossn_embed_add_object3('192.168.1.38', $videourl, $guid, $videowidth, $videoheight);
	return $embed_object;}
function ossn_embed_vimeo_parse_url3($url) {
	// separate parsing embed url
	if (strpos($url, 'object') != false) {
		return ossn_embed_vimeo_parse_embed3($url);	}
	if (strpos($url, 'post') != false) {
		if (!preg_match('/(http:\/\/)(www\.)?(192.168.1.38\/post\/photo\/)([0-9]*)\/([0-9a-zA-Z_-]*).([a-z]*)(\?)([0-9a-zA-Z_-]*)=([0-9a-zA-Z_-]*)/', $url, $matches)) {
			//echo "malformed vimeo group url";
			return;	}
		return $matches[0]; } }





