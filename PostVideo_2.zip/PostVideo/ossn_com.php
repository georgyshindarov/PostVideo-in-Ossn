<?php
define('__OSSN_POST__VIDEO', ossn_route()->com . 'PostVideo/');
function ossn_post_video() {if (ossn_isLoggedin()) {					
	$video_button = array('name' => 'post_video',
	'class' => 'ossn-wall-photo','text' => '<i class="fa fa-video"></i>',);	
	ossn_register_menu_item('wall/container/controls/home', $video_button);	
	ossn_register_menu_item('wall/container/controls/user', $video_button);	
	ossn_register_menu_item('wall/container/controls/group', $video_button);}}
    ossn_register_callback('ossn', 'init', 'ossn_post_video');
    

require_once(__OSSN_POST__VIDEO . 'libraries/ossnembed.lib.php');
require_once(__OSSN_POST__VIDEO . 'vendors/linkify/linkify.php');

/**
 * Initialize Ossn Embed component
 *
 * @note Please don't call this function directly in your code.
 * 
 * @return void
 * @access private
 */
function ossn_embed_init3() {	
 	ossn_add_hook('wall', 'templates:item', 'ossn_embed_wall_template_item3');
	ossn_add_hook('comment:view', 'template:params', 'ossn_embed_comments_template_params3');
	ossn_extend_view('css/ossn.default', 'css/embed');
}
/**https://player.vimeo.com/video/15371813
 * Replace videos links and simple url to html url.
 *
 * @note Please don't call this function directly in your code.
 * 
 * @param string $hook Name of hook
 * @param string $type Hook type
 * @param array|object $return Array or Object
 * @params array $params Array contatins params
 *
 * @return array
 * @access private
 */
function ossn_embed_wall_template_item3($hook, $type, $return){
	$patterns = array('/(http:\/\/)(www\.)?(192.168.1.38\/post\/photo\/)([0-9]*)\/([0-9a-zA-Z_-]*).([a-z]*)(\?)([0-9a-zA-Z_-]*)=([0-9a-zA-Z_-]*)/',
	
	);
	$regex = "/<a[\s]+[^>]*?href[\s]?=[\s\"\']+"."(.*?)[\"\']+.*?>"."([^<]+|.*?)?<\/a>/";
	
	$return['text'] = linkify3($return['text']);
	if(preg_match_all($regex, $return['text'], $matches, PREG_SET_ORDER)){
	foreach($matches as $match){
			foreach ($patterns as $pattern){
				if (preg_match($pattern, $match[0]) > 0){
					$return['text'] = str_replace($match[0], ossn_embed_create_embed_object3($match[0], uniqid('videos_embed_'), 500), $return['text']);
				}				
			}
		}
	}
	return $return;
}
/**
 * Convert text links from comments into html links
 *
 * @note Please don't call this function directly in your code.
 * 
 * @param string $hook Name of hook
 * @param string $type Hook type
 * @param array|object $return Array or Object
 * @params array $params Array contatins params
 *
 * @return array
 * @access private
 */
function ossn_embed_comments_template_params3($hook, $type, $return, $params){
	if(isset($return['comment']['comments:post'])){
		$return['comment']['comments:post'] = linkify($return['comment']['comments:post']);
	}
	elseif(isset($return['comment']['comments:entity'])){
		$return['comment']['comments:entity'] = linkify($return['comment']['comments:entity']);
	}
	elseif(isset($return['comment']['comments:object'])){
		$return['comment']['comments:object'] = linkify($return['comment']['comments:object']);
	}	
	return $return;
}
//initilize ossn wall
ossn_register_callback('ossn', 'init', 'ossn_embed_init3');
