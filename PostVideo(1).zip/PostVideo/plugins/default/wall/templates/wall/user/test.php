<?php

$image = 'https://gradskitigar.com/post/photo/427/18997733ec258a9fcaf239cc55d53363.jpg?ossn_cache=ac7bed99';

?>