<?php
function ossn_embed_create_embed_object3($url, $guid, $videowidth=0) {
	if (!isset($url)) {
		return false;	}{
		return ossn_embed_vimeo_handler3($url, $guid, $videowidth);}  {
		return false;}}
function ossn_embed_add_css3($guid, $width, $height) {
	$videocss = "";
	$vars = array(
		'guid' => $guid,
		'width' => $width,
		'height' => $height);
	return ossn_call_hook('embed', 'video:css', $vars, $videocss);}
print_r($url);
function ossn_embed_add_object3($type, $url, $guid, $width, $height) {
	$videodiv = "<span id=\"ossnembed{$guid}\" class=\"ossn_embed_video ratio ratio-16x9\">";
	switch ($type) {
	   case 'gradskitigar':
                $videodiv .= "<iframe src=\" https://gradskitigar.com/post/photo/428/8d7d8ee069cb0cbbf816bbb65d56947e.jpg?ossn_cache=7f9671ed \" width=\"$width\" height=\"$height\" allowfullscreen></iframe>";
                break;	}
print_r($url);
	$videodiv .= "</span>";
	return $videodiv;}
function ossn_embed_calc_size3(&$width, &$height, $aspect_ratio, $toolbar_heigh) {
	if (!isset($width) || !is_numeric($width) || $width < 0) {
		$width = 500;}
	$height = round($width / $aspect_ratio) + $toolbar_height;}
function ossn_embed_vimeo_handler3($url, $guid, $videowidth) {
	// this extracts the core part of the url needed for embeding
	$videourl = ossn_embed_vimeo_parse_url3($url);
	if (!isset($videourl)) {
		return false;	}
	ossn_embed_calc_size3($videowidth, $videoheight, 400/300, 0);
	$embed_object = ossn_embed_add_css3($guid, $videowidth, $videoheight);
	$embed_object .= ossn_embed_add_object3('gradskitigar', $videourl, $guid, $videowidth, $videoheight);
	return $embed_object;}
function ossn_embed_vimeo_parse_url3($url) {
	// separate parsing embed url
	if (strpos($url, 'object') != false) {
		return ossn_embed_vimeo_parse_embed3($url);	}
	if (strpos($url, 'post') != false) {
		if (!preg_match('/(https:\/\/)(www\.)?(gradskitigar.com\/post\/photo\/)([0-9a-zA-Z_-]*)/', $url, $matches)) {
			//echo "malformed vimeo group url";
			return;	}
		return $matches[1]; } }





